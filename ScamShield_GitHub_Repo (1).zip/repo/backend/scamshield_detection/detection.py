"""Deterministic, explainable message indicators for a local teaching prototype.

This engine never visits a link, identifies a sender, or predicts a probability.
Its weights and thresholds are proposed design choices, not calibrated evidence.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
import ipaddress
import re
from types import MappingProxyType
import unicodedata
from urllib.parse import urlsplit

from .contracts import RiskLevel, ScanResult, validate_message


DEFAULT_ENGINE_VERSION = "rules-1.0"
DEFAULT_MEDIUM_THRESHOLD = 30
DEFAULT_HIGH_THRESHOLD = 60


@dataclass(frozen=True)
class RuleSpec:
    """Public rule metadata. Matching functions are kept separately below."""

    rule_id: str
    weight: int
    label: str
    explanation: str


RULES = (
    RuleSpec("urgency", 15, "Pressure to act quickly",
             "The message uses urgent language or a short deadline. Take time to verify it."),
    RuleSpec("threatened_loss", 20, "Threatened loss or restriction",
             "The message describes an account restriction, service loss or threatened legal action."),
    RuleSpec("credential_request", 35, "Request for sensitive credentials",
             "The message asks for a password, PIN, security code or financial details."),
    RuleSpec("payment_request", 25, "Request to send a payment",
             "The message asks for money or a fee. Confirm the recipient and reason independently."),
    RuleSpec("unusual_payment", 35, "Request for gift cards or cryptocurrency",
             "The message asks for gift cards or cryptocurrency, which may be difficult to recover."),
    RuleSpec("remote_access", 35, "Request for remote access",
             "The message asks you to install a remote-access tool or allow remote control."),
    RuleSpec("claimed_authority", 15, "Claimed official authority",
             "The message mentions an official organisation or security team. The claim has not been verified."),
    RuleSpec("reward_claim", 20, "Prize or refund claim",
             "The message offers a prize or asks you to claim a reward or refund."),
    RuleSpec("secrecy", 25, "Request to keep the action secret",
             "The message asks you to keep the matter secret or avoid discussing it with other people."),
    RuleSpec("link_http", 10, "Link uses HTTP",
             "A link uses HTTP rather than HTTPS. This weakens transport protection but does not prove a scam."),
    RuleSpec("link_shortener", 20, "Shortened link",
             "A link uses a known shortening service, so the destination is not visible in the message."),
    RuleSpec("link_ip", 25, "Link contains an IP address",
             "A link uses an IP address instead of a named domain. Check who operates that destination."),
    RuleSpec("link_punycode", 25, "Internationalised domain encoding",
             "A link contains a punycode hostname. Check that the domain is the one you intended to visit."),
    RuleSpec("link_credentials", 25, "User information embedded in a link",
             "A link contains user information before an @ sign. The actual host is the part after that sign."),
)

DEFAULT_WEIGHTS = MappingProxyType({rule.rule_id: rule.weight for rule in RULES})
SHORTENER_HOSTS = frozenset({
    "bit.ly", "tinyurl.com", "t.co", "cutt.ly", "rebrand.ly", "is.gd", "shorturl.at", "rb.gy",
})

_URL = re.compile(r"(?:https?://|www\.)[^\s<>\"']+", re.IGNORECASE)
_NEGATED_ACTION = re.compile(r"(?:\bdo\s+not|\bdon['’]?t|\bnever|\bnot\s+to)\s*$", re.IGNORECASE)
_URGENCY = re.compile(
    r"\b(?:urgent|urgently|immediately|final\s+(?:warning|notice)|act\s+now)\b"
    r"|\bwithin\s+\d+\s*(?:minutes?|hours?)\b"
)
_THREAT = re.compile(
    r"\b(?:your\s+)?(?:bank\s+)?account\s+(?:(?:has\s+been|will\s+be|is|was|may\s+be|could\s+be)\s+)?"
    r"(?:suspended|locked|blocked|restricted|closed)\b"
    r"|\b(?:close|suspend|block)\s+your\s+account\b"
    r"|\b(?:service|electricity|internet)\s+(?:will\s+be|is)\s+(?:cut\s+off|disconnected|suspended)\b"
    r"|\b(?:face\s+(?:arrest|legal\s+action)|warrant\s+for\s+your\s+arrest)\b"
)


def _request_pattern(actions: str, targets: str, span: int = 60) -> re.Pattern:
    # A bounded same-clause window is deliberately simpler than language analysis.
    return re.compile(rf"\b(?:{actions})\b[^.!?;\n]{{0,{span}}}?\b(?:{targets})\b")


_CREDENTIAL = _request_pattern(
    r"share|send|enter|provide|confirm|verify|update|reply\s+with|tell\s+us",
    r"password|pin|one[- ]time\s+(?:code|password)|otp|security\s+code|verification\s+code|"
    r"login\s+details|bank\s+details|card\s+(?:details|number)|cvv",
)
_PAYMENT_WORDS = _request_pattern(
    r"pay|transfer|send|deposit|make",
    r"payment|money|funds|fee|tax|balance|fine|charge|invoice",
)
_PAYMENT_AMOUNT = re.compile(
    r"\b(?:pay|transfer|send|deposit)\s+(?:[£$€]\s*\d+(?:[.,]\d+)?|"
    r"\d+(?:[.,]\d+)?\s*(?:pounds?|dollars?|euros?|gbp|usd|eur))\b"
)
_UNUSUAL = _request_pattern(
    r"pay|transfer|send|deposit|buy|purchase",
    r"gift\s*cards?|vouchers?|bitcoin|ethereum|cryptocurrency|crypto|usdt",
    span=80,
)
_REMOTE = _request_pattern(
    r"install|download|give|allow|enable",
    r"anydesk|teamviewer|remote\s+(?:access|control)",
    span=80,
)
_AUTHORITY = re.compile(r"\b(?:hmrc|royal\s+mail|police|bank\s+security\s+team|fraud\s+department)\b")
_REWARD = re.compile(
    r"\byou\s+(?:have\s+)?won\b|\byou\s+are\s+(?:a\s+|the\s+)?winner\b"
    r"|\bselected\s+for\s+(?:a\s+)?prize\b"
    r"|\b(?:claim|collect)\b[^.!?;\n]{0,45}\b(?:prize|reward|refund|lottery)\b"
)
_SECRET = re.compile(
    r"\bkeep\s+(?:this|it|the\s+matter)\s+(?:a\s+)?secret\b"
    r"|\b(?:do\s+not|don['’]?t)\s+(?:tell|discuss)\b[^.!?;\n]{0,40}\b(?:anyone|family|friends)\b"
)


def _has_request(pattern: re.Pattern, text: str) -> bool:
    """Ignore a directly negated action, but do not pretend to parse intent."""
    for match in pattern.finditer(text):
        prefix = text[max(0, match.start() - 30):match.start()]
        if not _NEGATED_ACTION.search(prefix):
            return True
    return False


def _link_indicators(text: str) -> set[str]:
    indicators: set[str] = set()
    for match in _URL.finditer(text):
        candidate = match.group().rstrip(".,;!?)}")
        candidate = "https://" + candidate if candidate.lower().startswith("www.") else candidate
        try:
            url = urlsplit(candidate)
            host = (url.hostname or "").casefold().rstrip(".")
        except ValueError:
            # Malformed bracketed hosts cannot be interpreted by this URL parser.
            continue
        if not host:
            continue
        if url.scheme.casefold() == "http":
            indicators.add("link_http")
        shortener_host = host[4:] if host.startswith("www.") else host
        if shortener_host in SHORTENER_HOSTS:
            indicators.add("link_shortener")
        try:
            ipaddress.ip_address(host)
        except ValueError:
            pass
        else:
            indicators.add("link_ip")
        if any(label.startswith("xn--") for label in host.split(".")):
            indicators.add("link_punycode")
        if url.username is not None or url.password is not None:
            indicators.add("link_credentials")
    return indicators


class RiskEngine:
    """Score a message using one contribution per enabled rule.

    ``weights`` supplies optional overrides; a zero weight disables that rule.
    Custom settings are for experiments and must be recorded with a new version.
    Configuration has read-only public properties and an immutable weight mapping.
    """

    def __init__(
        self,
        *,
        weights: Mapping[str, int] | None = None,
        medium_threshold: int = DEFAULT_MEDIUM_THRESHOLD,
        high_threshold: int = DEFAULT_HIGH_THRESHOLD,
        engine_version: str = DEFAULT_ENGINE_VERSION,
    ):
        if type(medium_threshold) is not int or type(high_threshold) is not int:
            raise ValueError("Thresholds must be integers.")
        if not 1 <= medium_threshold < high_threshold <= 100:
            raise ValueError("Thresholds must satisfy 1 <= Medium < High <= 100.")
        if not isinstance(engine_version, str) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{0,99}", engine_version):
            raise ValueError("Engine version must be 1 to 100 letters, numbers, dots, underscores or hyphens.")
        proposed_weights = dict(DEFAULT_WEIGHTS)
        if weights is not None:
            if not isinstance(weights, Mapping):
                raise ValueError("Weights must be a mapping of known rule IDs to integers.")
            for rule_id, weight in weights.items():
                if rule_id not in DEFAULT_WEIGHTS:
                    raise ValueError(f"Unknown rule ID: {rule_id!r}.")
                if type(weight) is not int or not 0 <= weight <= 100:
                    raise ValueError("Each weight must be an integer between 0 and 100.")
                proposed_weights[rule_id] = weight
        if not any(proposed_weights.values()):
            raise ValueError("At least one rule must have a positive weight.")
        changed = (
            proposed_weights != dict(DEFAULT_WEIGHTS)
            or medium_threshold != DEFAULT_MEDIUM_THRESHOLD
            or high_threshold != DEFAULT_HIGH_THRESHOLD
        )
        if changed and engine_version == DEFAULT_ENGINE_VERSION:
            raise ValueError("Custom weights or thresholds require a distinct engine version.")
        self._weights = MappingProxyType(proposed_weights)
        self._medium_threshold = medium_threshold
        self._high_threshold = high_threshold
        self._engine_version = engine_version

    @property
    def weights(self) -> Mapping[str, int]:
        return self._weights

    @property
    def medium_threshold(self) -> int:
        return self._medium_threshold

    @property
    def high_threshold(self) -> int:
        return self._high_threshold

    @property
    def engine_version(self) -> str:
        return self._engine_version

    @property
    def rule_table(self) -> tuple[dict, ...]:
        """Return copies of rule metadata suitable for documentation or a UI."""
        return tuple({
            "rule_id": rule.rule_id,
            "weight": self.weights[rule.rule_id],
            "label": rule.label,
            "explanation": rule.explanation,
        } for rule in RULES)

    def risk_level_for_score(self, score: int) -> RiskLevel:
        if type(score) is not int or not 0 <= score <= 100:
            raise ValueError("Score must be an integer between 0 and 100.")
        if score >= self.high_threshold:
            return "High"
        if score >= self.medium_threshold:
            return "Medium"
        return "Low"

    def scan(self, text: str) -> ScanResult:
        validated = validate_message(text)
        normalised = unicodedata.normalize("NFKC", validated).casefold()
        matches = _link_indicators(normalised)
        content_matches = {
            "urgency": bool(_URGENCY.search(normalised)),
            "threatened_loss": bool(_THREAT.search(normalised)),
            "credential_request": _has_request(_CREDENTIAL, normalised),
            "payment_request": (
                _has_request(_PAYMENT_WORDS, normalised)
                or _has_request(_PAYMENT_AMOUNT, normalised)
            ),
            "unusual_payment": _has_request(_UNUSUAL, normalised),
            "remote_access": _has_request(_REMOTE, normalised),
            "claimed_authority": bool(_AUTHORITY.search(normalised)),
            "reward_claim": bool(_REWARD.search(normalised)),
            "secrecy": bool(_SECRET.search(normalised)),
        }
        matches.update(rule_id for rule_id, matched in content_matches.items() if matched)
        selected = tuple(rule for rule in RULES if rule.rule_id in matches and self.weights[rule.rule_id] > 0)
        score = min(100, sum(self.weights[rule.rule_id] for rule in selected))
        return ScanResult(
            score=score,
            risk_level=self.risk_level_for_score(score),
            reasons=tuple(rule.explanation for rule in selected),
            matched_rules=tuple(rule.rule_id for rule in selected),
            engine_version=self.engine_version,
        )

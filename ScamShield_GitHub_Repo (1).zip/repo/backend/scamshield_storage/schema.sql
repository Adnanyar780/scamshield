-- Five-table persistence schema. Each application connection must enable foreign_keys.
CREATE TABLE IF NOT EXISTS Users (
    user_id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL CHECK (typeof(name) = 'text' AND length(trim(name)) > 0),
    email TEXT NOT NULL COLLATE NOCASE UNIQUE
        CHECK (typeof(email) = 'text' AND instr(email, '@') > 1
               AND instr(email, ' ') = 0),
    role TEXT NOT NULL CHECK (role IN ('older', 'family')),
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

CREATE TABLE IF NOT EXISTS Messages (
    message_id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES Users(user_id) ON DELETE CASCADE,
    message_text TEXT NOT NULL
        CHECK (typeof(message_text) = 'text' AND length(trim(message_text)) > 0
               AND length(message_text) <= 5000 AND instr(message_text, char(0)) = 0),
    received_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

CREATE TABLE IF NOT EXISTS ScanResults (
    scan_id INTEGER PRIMARY KEY AUTOINCREMENT,
    message_id INTEGER NOT NULL UNIQUE
        REFERENCES Messages(message_id) ON DELETE CASCADE,
    score INTEGER NOT NULL CHECK (typeof(score) = 'integer' AND score BETWEEN 0 AND 100),
    risk_level TEXT NOT NULL CHECK (risk_level IN ('Low', 'Medium', 'High')),
    reasons_json TEXT NOT NULL CHECK (
        CASE WHEN json_valid(reasons_json) THEN json_type(reasons_json) = 'array' ELSE 0 END
    ),
    matched_rules_json TEXT NOT NULL CHECK (
        CASE WHEN json_valid(matched_rules_json)
             THEN json_type(matched_rules_json) = 'array' ELSE 0 END
    ),
    engine_version TEXT NOT NULL
        CHECK (typeof(engine_version) = 'text' AND length(trim(engine_version)) > 0),
    scanned_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
    CHECK (CASE WHEN json_valid(reasons_json) AND json_valid(matched_rules_json)
                THEN json_array_length(reasons_json) = json_array_length(matched_rules_json)
                ELSE 0 END)
);

CREATE TABLE IF NOT EXISTS FamilyRelationships (
    relationship_id INTEGER PRIMARY KEY AUTOINCREMENT,
    older_user_id INTEGER NOT NULL REFERENCES Users(user_id) ON DELETE CASCADE,
    family_user_id INTEGER NOT NULL REFERENCES Users(user_id) ON DELETE CASCADE,
    active INTEGER NOT NULL DEFAULT 1 CHECK (typeof(active) = 'integer' AND active IN (0, 1)),
    approved_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
    UNIQUE (older_user_id, family_user_id),
    CHECK (older_user_id <> family_user_id)
);

CREATE TABLE IF NOT EXISTS Alerts (
    alert_id INTEGER PRIMARY KEY AUTOINCREMENT,
    scan_id INTEGER NOT NULL REFERENCES ScanResults(scan_id) ON DELETE CASCADE,
    relationship_id INTEGER NOT NULL
        REFERENCES FamilyRelationships(relationship_id) ON DELETE CASCADE,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
    reviewed_at TEXT CHECK (reviewed_at IS NULL OR length(trim(reviewed_at)) > 0),
    UNIQUE (scan_id, relationship_id)
);

CREATE INDEX IF NOT EXISTS idx_messages_owner ON Messages(user_id, message_id DESC);
CREATE INDEX IF NOT EXISTS idx_family_recipient ON FamilyRelationships(family_user_id, active);
CREATE INDEX IF NOT EXISTS idx_alerts_relationship ON Alerts(relationship_id, alert_id DESC);

CREATE TRIGGER IF NOT EXISTS users_role_immutable
BEFORE UPDATE OF role ON Users WHEN NEW.role <> OLD.role
BEGIN
    SELECT RAISE(ABORT, 'account role cannot change');
END;

CREATE TRIGGER IF NOT EXISTS messages_older_owner
BEFORE INSERT ON Messages
WHEN NOT EXISTS (SELECT 1 FROM Users WHERE user_id = NEW.user_id AND role = 'older')
BEGIN
    SELECT RAISE(ABORT, 'message owner must have the older role');
END;

CREATE TRIGGER IF NOT EXISTS messages_no_update
BEFORE UPDATE ON Messages
BEGIN
    SELECT RAISE(ABORT, 'stored messages are immutable');
END;

-- A user deletion may cascade; individual history rows cannot be removed.
CREATE TRIGGER IF NOT EXISTS messages_no_independent_delete
BEFORE DELETE ON Messages WHEN EXISTS (SELECT 1 FROM Users WHERE user_id = OLD.user_id)
BEGIN
    SELECT RAISE(ABORT, 'delete the account to remove its message history');
END;

CREATE TRIGGER IF NOT EXISTS scans_string_arrays
BEFORE INSERT ON ScanResults
BEGIN
    SELECT CASE WHEN json_valid(NEW.reasons_json) = 0
        OR json_valid(NEW.matched_rules_json) = 0
        THEN RAISE(ABORT, 'result arrays must contain valid JSON') END;
    SELECT CASE WHEN EXISTS (
        SELECT 1 FROM json_each(NEW.reasons_json)
        WHERE type <> 'text' OR length(trim(value)) = 0
    ) OR EXISTS (
        SELECT 1 FROM json_each(NEW.matched_rules_json)
        WHERE type <> 'text' OR length(trim(value)) = 0
    ) THEN RAISE(ABORT, 'result array entries must be nonempty strings') END;
END;

CREATE TRIGGER IF NOT EXISTS scans_no_update
BEFORE UPDATE ON ScanResults
BEGIN
    SELECT RAISE(ABORT, 'stored scan results are immutable');
END;

CREATE TRIGGER IF NOT EXISTS scans_no_independent_delete
BEFORE DELETE ON ScanResults
WHEN EXISTS (SELECT 1 FROM Messages WHERE message_id = OLD.message_id)
BEGIN
    SELECT RAISE(ABORT, 'scan results belong to message history');
END;

CREATE TRIGGER IF NOT EXISTS family_correct_roles
BEFORE INSERT ON FamilyRelationships
WHEN NOT EXISTS (SELECT 1 FROM Users WHERE user_id = NEW.older_user_id AND role = 'older')
  OR NOT EXISTS (SELECT 1 FROM Users WHERE user_id = NEW.family_user_id AND role = 'family')
BEGIN
    SELECT RAISE(ABORT, 'family link requires an older account and a family account');
END;

CREATE TRIGGER IF NOT EXISTS family_identity_immutable
BEFORE UPDATE OF older_user_id, family_user_id ON FamilyRelationships
WHEN NEW.older_user_id <> OLD.older_user_id OR NEW.family_user_id <> OLD.family_user_id
BEGIN
    SELECT RAISE(ABORT, 'family link identity cannot change');
END;

CREATE TRIGGER IF NOT EXISTS family_revocation_clears_alerts
AFTER UPDATE OF active ON FamilyRelationships WHEN OLD.active = 1 AND NEW.active = 0
BEGIN
    DELETE FROM Alerts WHERE relationship_id = NEW.relationship_id;
END;

CREATE TRIGGER IF NOT EXISTS alerts_eligible
BEFORE INSERT ON Alerts
WHEN NOT EXISTS (
    SELECT 1 FROM ScanResults AS s
    JOIN Messages AS m ON m.message_id = s.message_id
    JOIN FamilyRelationships AS f ON f.older_user_id = m.user_id
    WHERE s.scan_id = NEW.scan_id AND f.relationship_id = NEW.relationship_id
      AND s.risk_level = 'High' AND f.active = 1
)
BEGIN
    SELECT RAISE(ABORT, 'alert requires a High scan and its owner active family link');
END;

CREATE TRIGGER IF NOT EXISTS alerts_identity_immutable
BEFORE UPDATE OF scan_id, relationship_id ON Alerts
WHEN NEW.scan_id <> OLD.scan_id OR NEW.relationship_id <> OLD.relationship_id
BEGIN
    SELECT RAISE(ABORT, 'alert identity cannot change');
END;

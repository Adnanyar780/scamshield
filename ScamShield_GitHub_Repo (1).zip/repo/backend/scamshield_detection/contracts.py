"""Small, validated interface shared by detection and persistence."""

from dataclasses import dataclass
from typing import Literal

MAX_MESSAGE_LENGTH = 5000
RiskLevel = Literal["Low", "Medium", "High"]


def validate_storage_text(value: str, label: str = "Text") -> str:
    if not isinstance(value, str):
        raise ValueError(f"{label} must be text.")
    if "\x00" in value:
        raise ValueError(f"{label} cannot contain a NUL character.")
    try:
        value.encode("utf-8")
    except UnicodeEncodeError as error:
        raise ValueError(f"{label} must contain valid Unicode text.") from error
    return value


def validate_message(text: str) -> str:
    validate_storage_text(text, "Message")
    text = text.strip()
    if not text:
        raise ValueError("Enter a message to check.")
    if len(text) > MAX_MESSAGE_LENGTH:
        raise ValueError(f"Message must contain at most {MAX_MESSAGE_LENGTH} characters.")
    return text


@dataclass(frozen=True)
class ScanResult:
    """Score is an indicator total, never a probability of fraud."""

    score: int
    risk_level: RiskLevel
    reasons: tuple[str, ...]
    matched_rules: tuple[str, ...]
    engine_version: str = "rules-1.0"

    def __post_init__(self):
        if type(self.score) is not int or not 0 <= self.score <= 100:
            raise ValueError("Score must be an integer between 0 and 100.")
        if self.risk_level not in ("Low", "Medium", "High"):
            raise ValueError("Risk level must be Low, Medium or High.")
        for name in ("reasons", "matched_rules"):
            values = getattr(self, name)
            if not isinstance(values, tuple) or len(values) > 50:
                raise ValueError(f"{name} must be a tuple containing at most 50 values.")
            if any(not isinstance(x, str) or not x.strip() or len(x) > 1000 for x in values):
                raise ValueError(f"Invalid value in {name}.")
            for value in values:
                validate_storage_text(value, name)
        if len(self.reasons) != len(self.matched_rules):
            raise ValueError("Each matched rule must have one explanation.")
        if len(set(self.matched_rules)) != len(self.matched_rules):
            raise ValueError("A rule can only contribute once.")
        if not isinstance(self.engine_version, str) or not self.engine_version.strip() or len(self.engine_version) > 100:
            raise ValueError("Engine version must be a short non-empty string.")
        validate_storage_text(self.engine_version, "Engine version")

    def to_dict(self) -> dict:
        return {
            "score": self.score,
            "risk_level": self.risk_level,
            "reasons": list(self.reasons),
            "matched_rules": list(self.matched_rules),
            "engine_version": self.engine_version,
        }

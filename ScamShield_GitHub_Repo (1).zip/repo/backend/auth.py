"""Ahmed's authentication: accounts, sessions and CSRF protection.

Passwords live in a separate SQLite file (instance/auth.sqlite3) because Lavinia's
database rejects any schema that differs from her five tables. Each auth account
maps explicitly to a Users.user_id in her database (storage_user_id).
"""
import hmac
import secrets
import sqlite3
from pathlib import Path

from flask import current_app, session
from werkzeug.security import check_password_hash, generate_password_hash

SCHEMA = """
CREATE TABLE IF NOT EXISTS AuthAccounts (
    auth_id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT NOT NULL UNIQUE COLLATE NOCASE,
    password_hash TEXT NOT NULL,
    storage_user_id INTEGER NOT NULL UNIQUE,
    role TEXT NOT NULL CHECK (role IN ('older','family'))
);
"""


def _connect():
    path = Path(current_app.instance_path) / "auth.sqlite3"
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    conn.executescript(SCHEMA)
    return conn


def create_account(email, password, storage_user_id, role):
    with _connect() as conn:
        conn.execute(
            "INSERT INTO AuthAccounts(email, password_hash, storage_user_id, role) VALUES (?,?,?,?)",
            (email, generate_password_hash(password), storage_user_id, role))


def verify_login(email, password):
    with _connect() as conn:
        row = conn.execute("SELECT * FROM AuthAccounts WHERE email = ?", (email,)).fetchone()
    # Always run a hash check so response time does not reveal whether the email exists.
    dummy = "scrypt:32768:8:1$x$" + "0" * 128
    ok = check_password_hash(row["password_hash"] if row else dummy, password)
    return dict(row) if row and ok else None


def find_by_email(email):
    with _connect() as conn:
        row = conn.execute("SELECT * FROM AuthAccounts WHERE email = ?", (email,)).fetchone()
    return dict(row) if row else None


def login_session(account):
    session.clear()
    session["storage_user_id"] = account["storage_user_id"]
    session["role"] = account["role"]
    session["csrf"] = secrets.token_urlsafe(32)


# ---- the three callbacks Lavinia's component needs -------------------------
def current_storage_account():
    """SCAMSHIELD_ACTOR_PROVIDER: trusted server session only, never browser input."""
    uid = session.get("storage_user_id")
    return uid if type(uid) is int and uid > 0 else None


def validate_write_request():
    """SCAMSHIELD_CSRF_VALIDATOR: must return exactly True."""
    from flask import request
    expected = session.get("csrf")
    supplied = request.headers.get("X-CSRF-Token", "")
    return bool(expected) and hmac.compare_digest(str(expected), supplied) is True

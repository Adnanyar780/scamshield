"""JSON adapter. Authentication and request protection are supplied by the backend."""

from functools import wraps
import sqlite3

from flask import Blueprint, current_app, g, jsonify, request
from werkzeug.exceptions import BadRequest, RequestEntityTooLarge

from .contracts import validate_result
from .database import AccessDenied, NotFound, _message
from .flask_extension import get_db

ROUTES = ("/scan", "/history", "/family/alerts", "/family/alerts/<int:alert_id>/review",
          "/family/links", "/family/links/<int:relationship_id>")


class APIError(Exception):
    def __init__(self, code, message, status):
        self.code, self.message, self.status = code, message, status


def _failure(code, message, status):
    return jsonify(error={"code": code, "message": message}), status


def _body(fields):
    if not request.is_json:
        raise APIError("json_required", "Send an application/json request body.", 415)
    payload = request.get_json()
    if not isinstance(payload, dict) or set(payload) != set(fields):
        raise APIError("invalid_fields", "Expected fields: " + ", ".join(fields) + ".", 400)
    return payload


def _page():
    if set(request.args) - {"limit", "offset"} or any(len(request.args.getlist(k)) != 1 for k in request.args):
        raise APIError("invalid_query", "Only one limit and one offset are accepted.", 400)
    try:
        return int(request.args.get("limit", "20")), int(request.args.get("offset", "0"))
    except ValueError:
        raise APIError("invalid_pagination", "limit and offset must be integers.", 400) from None


def _handled(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        try:
            return view(*args, **kwargs)
        except APIError as exc:
            return _failure(exc.code, exc.message, exc.status)
        except AccessDenied:
            return _failure("access_denied", "This operation is not permitted for this account.", 403)
        except NotFound:
            return _failure("not_found", "The requested account or record was not found.", 404)
        except (ValueError, TypeError) as exc:
            return _failure("invalid_input", str(exc), 400)
        except sqlite3.IntegrityError:
            return _failure("record_conflict", "The operation conflicts with a database rule.", 409)
        except sqlite3.OperationalError as exc:
            if getattr(exc, "sqlite_errorcode", None) in (sqlite3.SQLITE_BUSY, sqlite3.SQLITE_LOCKED):
                return _failure("database_busy", "Please try this operation again.", 503)
            current_app.logger.exception("ScamShield database operation failed")
            return _failure("database_unavailable", "The database operation could not complete.", 503)
        except RuntimeError:
            current_app.logger.warning("ScamShield storage configuration prevented this operation")
            return _failure("storage_not_configured", "The storage configuration needs a backend review.", 503)
    return wrapped


def create_blueprint():
    bp = Blueprint("scamshield_storage_api", __name__)

    @bp.before_request
    @_handled
    def require_identity_and_request_protection():
        configured_limit = request.max_content_length
        request.max_content_length = min(configured_limit, 65536) if configured_limit is not None else 65536
        provider = current_app.config.get("SCAMSHIELD_ACTOR_PROVIDER")
        if not callable(provider):
            raise APIError("authentication_not_configured", "The backend account adapter is not configured.", 503)
        try:
            actor = provider()
        except Exception:
            raise APIError("authentication_unavailable", "The backend account adapter could not complete.", 503) from None
        if type(actor) is not int or actor < 1:
            raise APIError("login_required", "Sign in to use this feature.", 401)
        g._scamshield_storage_actor = actor
        if request.method in {"POST", "PUT", "PATCH", "DELETE"}:
            validator = current_app.config.get("SCAMSHIELD_CSRF_VALIDATOR")
            if not callable(validator):
                raise APIError("request_protection_not_configured", "The backend write-request check is not configured.", 503)
            try:
                valid = validator()
            except Exception:
                raise APIError("request_protection_unavailable", "The backend write-request check could not complete.", 503) from None
            if valid is not True:
                raise APIError("request_rejected", "The write-request check failed.", 403)

    @bp.after_request
    def private_response(response):
        response.headers["Cache-Control"] = "no-store"
        response.headers["X-Content-Type-Options"] = "nosniff"
        return response

    @bp.errorhandler(BadRequest)
    def bad_json(_error):
        return _failure("invalid_json", "The JSON request body is invalid.", 400)

    @bp.errorhandler(RequestEntityTooLarge)
    def body_too_large(_error):
        return _failure("body_too_large", "The request body is too large.", 413)

    @bp.post("/scan")
    @_handled
    def scan():
        # The browser supplies text only. Detector scores are calculated on the server.
        text = _message(_body(("message_text",))["message_text"])
        database = get_db()
        actor = g._scamshield_storage_actor
        with database.connection() as connection:
            database._account(connection, actor, "older")
        detector = current_app.config.get("SCAMSHIELD_DETECTOR")
        if not callable(detector):
            raise APIError("detector_not_configured", "The message detector is not connected.", 503)
        try:
            result = validate_result(detector(text))
        except Exception as exc:
            # No detector details or message content are sent back in an error.
            current_app.logger.warning("ScamShield detector did not return an accepted result: %s", type(exc).__name__)
            raise APIError("detector_failed", "The message could not be evaluated. Nothing was saved.", 502) from None
        saved = database.record_scan(actor, text, result, actor_user_id=actor)
        return jsonify(saved), 201

    @bp.get("/history")
    @_handled
    def history():
        limit, offset = _page()
        actor = g._scamshield_storage_actor
        return jsonify(get_db().list_history(actor, actor_user_id=actor, limit=limit, offset=offset))

    @bp.get("/family/alerts")
    @_handled
    def alerts():
        limit, offset = _page()
        actor = g._scamshield_storage_actor
        return jsonify(get_db().family_alerts(actor, actor_user_id=actor, limit=limit, offset=offset))

    @bp.post("/family/alerts/<int:alert_id>/review")
    @_handled
    def review(alert_id):
        _body(())
        return jsonify(get_db().review_alert(alert_id, actor_user_id=g._scamshield_storage_actor))

    @bp.post("/family/links")
    @_handled
    def approve_link():
        family = _body(("family_user_id",))["family_user_id"]
        actor = g._scamshield_storage_actor
        return jsonify(get_db().link_family(actor, family, actor_user_id=actor)), 201

    @bp.delete("/family/links/<int:relationship_id>")
    @_handled
    def revoke_link(relationship_id):
        _body(())
        return jsonify(get_db().revoke_family_link(relationship_id, actor_user_id=g._scamshield_storage_actor))

    return bp

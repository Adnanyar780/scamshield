ScamShield backend (Ahmed)

Run (Windows or any OS, Python 3.12+):
    python -m venv .venv
    .venv\Scripts\activate.bat
    python -m pip install -r requirements.txt
    python -m flask --app app run
Open http://127.0.0.1:5000 (placeholder page; Khalil's UI replaces templates/index.html)

Tests:   python -m unittest discover -s tests -v
DB check: python -m flask --app app scamshield-db-check

Files
  app.py       Flask app, auth routes, family link route, wires Lavinia's component
  auth.py      accounts (separate instance/auth.sqlite3), sessions, the 2 callbacks
  detector.py  PLACEHOLDER rules. Daneil replaces evaluate_message() (same return contract)
  scamshield_storage/  Lavinia's component, unchanged

Endpoints
  POST /api/auth/register {name,email,password,role}   -> csrf_token
  POST /api/auth/login    {email,password}              -> csrf_token
  GET  /api/auth/me   POST /api/auth/logout
  POST /api/family/link {family_email}                  (older user)
  POST /api/scamshield/scan {message_text}              (X-CSRF-Token header)
  GET  /api/scamshield/history
  GET  /api/scamshield/family/alerts
  POST /api/scamshield/family/alerts/<id>/review

Before real use set SCAMSHIELD_SECRET_KEY to a long random value.

Family dashboard (Adnan's part)
  Page:   /family   (templates/family.html, static/family.css, static/family.js)
  Demo:   python seed_demo.py   then run the app and sign in at /family as
          daniel@example.com / password123   (older demo account: margaret@example.com)
  Features: sign in, needs-review and all-alerts tabs, risk score bar, reasons,
            mark as reviewed, load more, auto-refresh every 30 seconds.
  Message text is shown with textContent only (senders are untrusted).
  Not built: AWS notification / QR page (optional, only after the core works).

Detector (Daneil's part)
  Daneil's rules-1.0 engine is in scamshield_detection/ and is connected in app.py by
  init_detection(app) before the storage init. The old placeholder detector.py is removed.
  Score is an indicator total (0-100), NOT a probability; the UI says "score X/100".
  Check: python -m flask --app app scamshield-detector-check

Older-user interface (Khalil Penpot design)
  templates/index.html + static/app.css + static/app.js: home, check, result, history, family alert, dashboard, about, plus sign-in/register.
  Family accounts are redirected to /family (Adnan dashboard).

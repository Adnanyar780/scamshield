"""SQLite persistence with account-scoped operations and explicit transactions."""

from contextlib import contextmanager
import json
from pathlib import Path
import sqlite3

from .contracts import validate_result


class AccessDenied(PermissionError):
    pass


class NotFound(LookupError):
    pass


def _identifier(value, field):
    if type(value) is not int or value < 1:
        raise ValueError(f"{field} must be a positive integer")
    return value


def _text(value, field):
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{field} must be a nonempty string")
    return value


def _message(value):
    value = _text(value, "message_text")
    if len(value) > 5000:
        raise ValueError("message_text must not exceed 5000 characters")
    if "\x00" in value:
        raise ValueError("message_text must not contain NUL characters")
    try:
        value.encode("utf-8")
    except UnicodeEncodeError:
        raise ValueError("message_text must contain valid Unicode") from None
    return value


def _pagination(limit, offset):
    if type(limit) is not int or not 1 <= limit <= 100:
        raise ValueError("limit must be an integer from 1 to 100")
    if type(offset) is not int or offset < 0:
        raise ValueError("offset must be a nonnegative integer")


def _result(row):
    return {
        "score": row["score"],
        "risk_level": row["risk_level"],
        "reasons": json.loads(row["reasons_json"]),
        "matched_rules": json.loads(row["matched_rules_json"]),
        "engine_version": row["engine_version"],
    }


class Database:
    """Actor IDs must come from an authenticated backend, never a request form."""

    def __init__(self, path):
        if str(path) == ":memory:":
            raise ValueError("use a file database because operations open separate connections")
        self.path = Path(path)

    @contextmanager
    def connection(self):
        """Open a foreign-key-enforcing connection; intended for trusted server code."""
        connection = sqlite3.connect(self.path, timeout=10, isolation_level=None)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys = ON")
        connection.execute("PRAGMA recursive_triggers = ON")
        if connection.execute("PRAGMA foreign_keys").fetchone()[0] != 1:
            connection.close()
            raise RuntimeError("foreign key enforcement is required")
        try:
            yield connection
        finally:
            connection.close()

    @contextmanager
    def _transaction(self):
        with self.connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            try:
                yield connection
                connection.commit()
            except BaseException:
                connection.rollback()
                raise

    def initialize(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        schema = Path(__file__).with_name("schema.sql").read_text(encoding="utf-8")
        with self.connection() as connection:
            if connection.execute("SELECT json_valid('[]')").fetchone()[0] != 1:
                raise RuntimeError("SQLite JSON functions are required")
            try:
                connection.executescript("BEGIN IMMEDIATE;\n" + schema + "\nCOMMIT;")
            except BaseException:
                connection.rollback()
                raise

    @staticmethod
    def _account(connection, user_id, required_role=None):
        row = connection.execute("SELECT * FROM Users WHERE user_id = ?", (user_id,)).fetchone()
        if row is None:
            raise NotFound("account was not found")
        if required_role and row["role"] != required_role:
            raise AccessDenied(f"operation requires the {required_role} role")
        return row

    @staticmethod
    def _same_actor(user_id, actor_user_id):
        _identifier(user_id, "user_id")
        _identifier(actor_user_id, "actor_user_id")
        if user_id != actor_user_id:
            raise AccessDenied("actor cannot access another account")

    def create_user(self, name, email, role):
        name = _text(name, "name").strip()
        email = _text(email, "email").strip().lower()
        if email.count("@") != 1 or any(character.isspace() for character in email):
            raise ValueError("email must contain one @ and no whitespace")
        if not all(email.split("@")):
            raise ValueError("email must have local and domain parts")
        if role not in ("older", "family"):
            raise ValueError("role must be older or family")
        with self._transaction() as connection:
            cursor = connection.execute(
                "INSERT INTO Users(name, email, role) VALUES (?, ?, ?)", (name, email, role)
            )
            return dict(self._account(connection, cursor.lastrowid))

    def link_family(self, older_user_id, family_user_id, *, actor_user_id):
        self._same_actor(older_user_id, actor_user_id)
        _identifier(family_user_id, "family_user_id")
        with self._transaction() as connection:
            self._account(connection, older_user_id, "older")
            self._account(connection, family_user_id, "family")
            connection.execute(
                """INSERT INTO FamilyRelationships(older_user_id, family_user_id, active)
                   VALUES (?, ?, 1)
                   ON CONFLICT(older_user_id, family_user_id) DO UPDATE SET active = 1""",
                (older_user_id, family_user_id),
            )
            row = connection.execute(
                "SELECT * FROM FamilyRelationships WHERE older_user_id = ? AND family_user_id = ?",
                (older_user_id, family_user_id),
            ).fetchone()
            result = dict(row)
            result["active"] = bool(result["active"])
            return result

    def revoke_family_link(self, relationship_id, *, actor_user_id):
        _identifier(relationship_id, "relationship_id")
        _identifier(actor_user_id, "actor_user_id")
        with self._transaction() as connection:
            self._account(connection, actor_user_id, "older")
            row = connection.execute(
                "SELECT * FROM FamilyRelationships WHERE relationship_id = ? AND older_user_id = ?",
                (relationship_id, actor_user_id),
            ).fetchone()
            if row is None:
                raise AccessDenied("only the older account that owns the link can revoke it")
            count = connection.execute(
                "SELECT count(*) FROM Alerts WHERE relationship_id = ?", (relationship_id,)
            ).fetchone()[0]
            connection.execute(
                "UPDATE FamilyRelationships SET active = 0 WHERE relationship_id = ?", (relationship_id,)
            )
            return {"relationship_id": relationship_id, "active": False, "alerts_deleted": count}

    def record_scan(self, user_id, message_text, result, *, actor_user_id):
        self._same_actor(user_id, actor_user_id)
        message_text = _message(message_text)
        checked = validate_result(result)
        with self._transaction() as connection:
            self._account(connection, user_id, "older")
            message = connection.execute(
                "INSERT INTO Messages(user_id, message_text) VALUES (?, ?)", (user_id, message_text)
            )
            scan = connection.execute(
                """INSERT INTO ScanResults
                   (message_id, score, risk_level, reasons_json, matched_rules_json, engine_version)
                   VALUES (?, ?, ?, ?, ?, ?)""",
                (message.lastrowid, checked["score"], checked["risk_level"],
                 json.dumps(checked["reasons"], ensure_ascii=False),
                 json.dumps(checked["matched_rules"], ensure_ascii=False), checked["engine_version"]),
            )
            if checked["risk_level"] == "High":
                connection.execute(
                    """INSERT INTO Alerts(scan_id, relationship_id)
                       SELECT ?, relationship_id FROM FamilyRelationships
                       WHERE older_user_id = ? AND active = 1""",
                    (scan.lastrowid, user_id),
                )
            alert_ids = [row[0] for row in connection.execute(
                "SELECT alert_id FROM Alerts WHERE scan_id = ? ORDER BY alert_id", (scan.lastrowid,)
            )]
            return {"message_id": message.lastrowid, "scan_id": scan.lastrowid,
                    "result": checked, "alerts_created": len(alert_ids), "alert_ids": alert_ids}

    def list_history(self, user_id, *, actor_user_id, limit=20, offset=0):
        self._same_actor(user_id, actor_user_id)
        _pagination(limit, offset)
        with self.connection() as connection:
            self._account(connection, user_id, "older")
            rows = connection.execute(
                """SELECT m.*, s.* FROM Messages AS m
                   LEFT JOIN ScanResults AS s ON s.message_id = m.message_id
                   WHERE m.user_id = ? ORDER BY m.message_id DESC LIMIT ? OFFSET ?""",
                (user_id, limit, offset),
            ).fetchall()
            items = []
            for row in rows:
                scan = None if row["scan_id"] is None else {
                    "scan_id": row["scan_id"], "scanned_at": row["scanned_at"], "result": _result(row)
                }
                items.append({"message_id": row["message_id"], "message_text": row["message_text"],
                              "received_at": row["received_at"], "scan": scan})
            return {"user_id": user_id, "limit": limit, "offset": offset, "items": items}

    def family_alerts(self, user_id, *, actor_user_id, limit=20, offset=0):
        self._same_actor(user_id, actor_user_id)
        _pagination(limit, offset)
        with self.connection() as connection:
            self._account(connection, user_id, "family")
            rows = connection.execute(
                """SELECT a.*, m.message_id, m.message_text, m.user_id AS older_user_id,
                          u.name AS older_name, s.score, s.risk_level,
                          s.reasons_json, s.matched_rules_json, s.engine_version
                   FROM Alerts AS a
                   JOIN FamilyRelationships AS f ON f.relationship_id = a.relationship_id
                   JOIN ScanResults AS s ON s.scan_id = a.scan_id
                   JOIN Messages AS m ON m.message_id = s.message_id
                   JOIN Users AS u ON u.user_id = m.user_id
                   WHERE f.family_user_id = ? AND f.active = 1 AND s.risk_level = 'High'
                   ORDER BY a.alert_id DESC LIMIT ? OFFSET ?""",
                (user_id, limit, offset),
            ).fetchall()
            alerts = [dict(alert_id=row["alert_id"], scan_id=row["scan_id"],
                           relationship_id=row["relationship_id"], message_id=row["message_id"],
                           message_text=row["message_text"], older_user_id=row["older_user_id"],
                           older_name=row["older_name"], result=_result(row),
                           created_at=row["created_at"], reviewed_at=row["reviewed_at"])
                      for row in rows]
            return {"user_id": user_id, "limit": limit, "offset": offset, "alerts": alerts}

    def review_alert(self, alert_id, *, actor_user_id):
        _identifier(alert_id, "alert_id")
        _identifier(actor_user_id, "actor_user_id")
        with self._transaction() as connection:
            self._account(connection, actor_user_id, "family")
            row = connection.execute(
                """SELECT a.* FROM Alerts AS a
                   JOIN FamilyRelationships AS f ON f.relationship_id = a.relationship_id
                   WHERE a.alert_id = ? AND f.family_user_id = ? AND f.active = 1""",
                (alert_id, actor_user_id),
            ).fetchone()
            if row is None:
                raise AccessDenied("alert is not available to this family account")
            connection.execute(
                """UPDATE Alerts SET reviewed_at = COALESCE(
                       reviewed_at, strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
                   WHERE alert_id = ?""", (alert_id,)
            )
            return dict(connection.execute("SELECT * FROM Alerts WHERE alert_id = ?", (alert_id,)).fetchone())

    def delete_user(self, user_id, *, actor_user_id):
        self._same_actor(user_id, actor_user_id)
        with self._transaction() as connection:
            self._account(connection, user_id)
            connection.execute("DELETE FROM Users WHERE user_id = ?", (user_id,))
            return {"deleted_user_id": user_id, "deleted": True}

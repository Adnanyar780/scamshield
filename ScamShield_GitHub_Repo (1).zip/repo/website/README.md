# ScamShield website

Put the single-page website file here as `index.html`.
Open it directly in a browser. It runs fully client-side, with no server needed.

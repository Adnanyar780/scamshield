"use strict";
// Older-user app (Khalil's design from Penpot) wired to the Flask API.
// All text from the server or the user is inserted with textContent.
let csrf = "", role = "", mode = "login", last = null;
const $ = id => document.getElementById(id);
const el = (tag, cls, text) => { const e = document.createElement(tag); if (cls) e.className = cls; if (text !== undefined) e.textContent = text; return e; };

const LABEL = { High: "Message needs review", Medium: "Check it carefully before you trust it", Low: "Few warning signs found. Stay careful" };
const LINE = { High: "This message may be a scam.", Medium: "This message has some warning signs.", Low: "We found few warning signs, but no tool can promise a message is safe." };

async function api(path, method = "GET", body) {
  const r = await fetch(path, { method, credentials: "same-origin",
    headers: { "Content-Type": "application/json", "X-CSRF-Token": csrf },
    body: body === undefined ? undefined : JSON.stringify(body) });
  let j = {}; try { j = await r.json(); } catch (_) {}
  if (!r.ok) { const e = new Error(j.error?.message || "Something went wrong. Please try again."); e.status = r.status; throw e; }
  return j;
}

function go(name) { location.hash = "#" + name; }
function route() {
  let name = location.hash.slice(1) || "home";
  const known = [...document.querySelectorAll("[data-screen]")].map(s => s.dataset.screen);
  if (!known.includes(name)) name = "home";
  if (!role) name = "auth";
  document.querySelectorAll("[data-screen]").forEach(s => s.hidden = s.dataset.screen !== name);
  $("logout").hidden = !role;
  if (name === "history") loadHistory();
  if (name === "dashboard") loadDashboard();
  if (name === "family-alert") renderFamilyAlert();
  window.scrollTo(0, 0);
}
window.addEventListener("hashchange", route);

function enter(j) {
  if (j.role === "family") { location.href = "/family"; return; }
  csrf = j.csrf_token; role = j.role;
  if (!location.hash || location.hash === "#auth") location.hash = "#home";
  route();
}

// ---- auth
function setMode(m) {
  mode = m; $("regOnly").hidden = m !== "register";
  $("tabLogin").classList.toggle("on", m === "login"); $("tabRegister").classList.toggle("on", m === "register");
  $("authBtn").textContent = m === "login" ? "Sign in" : "Create account"; $("authErr").textContent = "";
}
$("tabLogin").onclick = () => setMode("login");
$("tabRegister").onclick = () => setMode("register");
$("authBtn").onclick = async () => {
  $("authErr").textContent = "";
  const b = { email: $("email").value, password: $("password").value };
  if (mode === "register") { b.name = $("name").value; b.role = $("role").value; }
  try { enter(await api("/api/auth/" + mode, "POST", b)); } catch (e) { $("authErr").textContent = e.message; }
};
$("logout").onclick = async () => { try { await api("/api/auth/logout", "POST", {}); } catch (_) {} role = ""; csrf = ""; location.hash = "#auth"; route(); };

// ---- check + result
$("scanBtn").onclick = async () => {
  $("scanErr").textContent = "";
  const text = $("msg").value.trim();
  if (!text) { $("scanErr").textContent = "Please paste a message first."; return; }
  $("scanBtn").disabled = true;
  try { last = await api("/api/scamshield/scan", "POST", { message_text: text }); $("msg").value = ""; showResult(); go("result"); }
  catch (e) { $("scanErr").textContent = e.message; }
  $("scanBtn").disabled = false;
};
function showResult() {
  const r = last.result;
  $("resSub").textContent = `${r.risk_level} Risk — ${LABEL[r.risk_level]}.`;
  const box = $("resBox"); box.className = "risk " + r.risk_level; box.textContent = r.risk_level + " Risk";
  $("resLine").textContent = LINE[r.risk_level];
  $("resScore").textContent = `Risk score: ${r.score}/100 (a guide, not a probability).`;
  const ul = $("resReasons"); ul.replaceChildren();
  const real = r.matched_rules.length ? r.reasons : ["No known warning signs were matched."];
  real.forEach(t => ul.append(el("li", "", t)));
  $("resFamily").hidden = r.risk_level !== "High";
}
function renderFamilyAlert() {
  if (!last) { go("home"); return; }
  const r = last.result, box = $("faBox"); box.className = "risk " + r.risk_level; box.textContent = r.risk_level + " Risk";
  $("faLevel").textContent = "Risk level: " + r.risk_level;
  $("faReason").textContent = "Reason: " + (r.reasons[0] || "suspicious wording or request");
  $("faSent").textContent = last.alerts_created > 0
    ? `${last.alerts_created} family member${last.alerts_created > 1 ? "s were" : " was"} alerted automatically.`
    : "No family member is linked yet, so nobody was alerted. Use Family Alert Settings to add one.";
}

// ---- history + dashboard
const fmt = iso => { const d = new Date(iso); return isNaN(d) ? "" : d.toLocaleString([], { dateStyle: "medium", timeStyle: "short" }); };
function item(i) {
  const level = i.scan?.result?.risk_level || "Low", d = el("div", "item");
  const b = el("b", level, `${level} Risk. ${LABEL[level]}`);
  d.append(b, el("small", "", (i.message_text.length > 90 ? i.message_text.slice(0, 90) + "…" : i.message_text) + " · " + fmt(i.received_at)));
  return d;
}
async function fetchHistory() { return (await api("/api/scamshield/history?limit=100&offset=0")).items; }
async function loadHistory() {
  const box = $("histList"); box.replaceChildren();
  try { const items = await fetchHistory(); if (!items.length) box.append(el("p", "note", "No messages checked yet.")); items.forEach(i => box.append(item(i))); }
  catch (e) { box.append(el("p", "err", e.message)); }
}
async function loadDashboard() {
  try {
    const items = await fetchHistory();
    $("stTotal").textContent = items.length; $("stHigh").textContent = items.filter(i => i.scan?.result?.risk_level === "High").length;
    const box = $("recent"); box.replaceChildren();
    if (!items.length) box.append(el("p", "note", "Nothing yet."));
    items.slice(0, 3).forEach(i => box.append(item(i)));
  } catch (e) { $("recent").replaceChildren(el("p", "err", e.message)); }
}

// ---- family support
$("famBtn").onclick = async () => {
  $("famMsg").textContent = "";
  try { await api("/api/family/link", "POST", { family_email: $("famEmail").value }); $("famMsg").textContent = "Family member added. They will be alerted about high-risk messages."; $("famEmail").value = ""; }
  catch (e) { $("famMsg").textContent = e.message; }
};

api("/api/auth/me").then(enter).catch(() => { role = ""; route(); });

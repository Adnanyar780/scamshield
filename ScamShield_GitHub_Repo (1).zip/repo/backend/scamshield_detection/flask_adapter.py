"""Connect the original rule engine to Flask without owning routes or storage."""

import json

import click
from flask import current_app

from .contracts import MAX_MESSAGE_LENGTH
from .detection import DEFAULT_ENGINE_VERSION, RiskEngine

EXTENSION_KEY = "scamshield_detection"
WORKED_MESSAGES = (
    "Your dentist appointment is tomorrow at 10:30. Call reception if you need to change it.",
    "Urgent. Reply with your verification code so I can finish the account check.",
    "Urgent. Your account will be suspended. Enter your password now.",
)


def _evaluate(engine, message):
    # The API and persistence limits concern the original submitted text.
    # The unchanged standalone validator trims before its own length check.
    if not isinstance(message, str):
        raise ValueError("Message must be text.")
    if len(message) > MAX_MESSAGE_LENGTH:
        raise ValueError("Submitted message must contain at most 5000 characters.")
    return engine.scan(message).to_dict()


def get_engine():
    binding = current_app.extensions.get(EXTENSION_KEY)
    if binding is None:
        raise RuntimeError("Initialise the detection adapter during Flask setup.")
    return binding["engine"]


def evaluate_message(message):
    """Return the five JSON-compatible fields expected by the shared storage API."""
    return _evaluate(get_engine(), message)


def init_app(app):
    """Register a server-side detector callback and its local verification command."""
    existing_binding = app.extensions.get(EXTENSION_KEY)
    if existing_binding is not None:
        if app.config.get("SCAMSHIELD_DETECTOR") is not existing_binding.get("callback"):
            raise RuntimeError("The detector callback changed after initialisation. Review the backend configuration.")
        return existing_binding
    existing_callback = app.config.get("SCAMSHIELD_DETECTOR")
    if existing_callback is not None and existing_callback is not evaluate_message:
        raise RuntimeError("A detector callback is already configured. Review it before installing another evaluator.")
    engine = RiskEngine(
        weights=app.config.get("SCAMSHIELD_DETECTION_WEIGHTS"),
        medium_threshold=app.config.get("SCAMSHIELD_DETECTION_MEDIUM_THRESHOLD", 30),
        high_threshold=app.config.get("SCAMSHIELD_DETECTION_HIGH_THRESHOLD", 60),
        engine_version=app.config.get("SCAMSHIELD_DETECTION_ENGINE_VERSION", DEFAULT_ENGINE_VERSION),
    )

    def callback(message):
        return _evaluate(engine, message)

    if "scamshield-detector-check" in app.cli.commands:
        raise RuntimeError("The scamshield-detector-check command is already registered.")
    binding = {"engine": engine, "callback": callback}
    app.extensions[EXTENSION_KEY] = binding
    app.config["SCAMSHIELD_DETECTOR"] = callback

    @app.cli.command("scamshield-detector-check")
    def detector_check():
        """Print the configured engine and three repeatable worked results."""
        output = {
            "engine_version": engine.engine_version,
            "rules": len(engine.rule_table),
            "weights": dict(engine.weights),
            "medium_threshold": engine.medium_threshold,
            "high_threshold": engine.high_threshold,
            "submitted_text_limit": MAX_MESSAGE_LENGTH,
            "examples": [dict(message=message, result=callback(message)) for message in WORKED_MESSAGES],
        }
        click.echo(json.dumps(output, indent=2))

    return binding
